package test.n3_fullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class N3FullstackApplication {

	public static void main(String[] args) {
		SpringApplication.run(N3FullstackApplication.class, args);
	}

}
