package test.n3_fullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class N3FullstackApplicationTests {

	@Test
	void contextLoads() {
	}

}
